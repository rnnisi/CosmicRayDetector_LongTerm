#!/bin/bash

git init
git add .
git remote set-url origin https://github.com/rnnisi/Cosmic-Ray-Detection/
git commit -m "new"
git push -u origin master
