#!/bin/bash

NEW=$(ls ../ -t | grep "Hour" | head -1)
echo $NEW
#git pull
cp -r "../$NEW" .
git add --all
git commit -m "$NEW"
git push origin main
sudo rm ../$NEW/* 

