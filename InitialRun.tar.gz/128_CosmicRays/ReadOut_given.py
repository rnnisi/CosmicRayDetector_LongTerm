#!/usr/bin/env python3

# Starting example of reading the Stretch signal on pin 37 and recording the time and rate.
import numpy  as  np
import math
import sys
import os
import os.path
from os import path
import RPi.GPIO as GPIO
import time
import datetime
import sys 


sys.exit()

GPIO.setmode(GPIO.BOARD)
GPIO.setup(37,GPIO.IN)

if len(sys.argv) < 3:
    print("You need to pass the run number and max time in seconds")
    exit()
    
RunNum = int(sys.argv[1])
maxtime = int(sys.argv[2])
# Make sure that the run directory is there
if not path.exists("/home/pi/150/data/Run"+sys.argv[1]):
    os.system("mkdir /home/pi/150/data/Run"+sys.argv[1])    

# We will save data in three ways in different files. 
#   First is a time stamp of every event.
#   Second is the count of events per minute of livetime.
#   Third is the final, overall summary.
# We will pause after each minute of livetime to update plots.
eventsfile = "/home/pi/150/data/Run"+sys.argv[1]+"/events.dat"
minutesfile = "/home/pi/150/data/Run"+sys.argv[1]+"/minutesrates.dat"
summaryfile = "/home/pi/150/data/Run"+sys.argv[1]+"/summary.dat"
# Open output files.
eventsOut = open(eventsfile, "w")
minutesOut = open(minutesfile, "w")

# Define the stopfile; when it exists we end the run
stopfile = "/home/pi/150/db/stop"

# Determine how long it takes to measure the time
time1 = datetime.datetime.now()
for i in range(1,1000000):
    time2 = datetime.datetime.now()
    timediff2 = time2 - time1
print("Time required to measure time = ",timediff2.total_seconds(),"microseconds")

# Determine how long it takes to check if the stopfile exists
time1 = datetime.datetime.now()
done = 0
for i in range(1,1000000):
    if path.exists(stopfile):
        done = 1
time2 = datetime.datetime.now()
timediff2 = time2 - time1
print("Time required to check stop file = ",timediff2.total_seconds(),"microseconds")

# Auxiliary data is currently just zeros as placeholders.
ADC1 = 0 # Pulse height for channel 1 (reserved for future)
ADC2 = 0 # Pulse height for channel 2 (reserved for future)
AUX1 = 0 # Reserved for future use
AUX2 = 0 # Reserved for future use 
AUX3 = 0 # Reserved for future use 

# Initialize the event counters and timers
nCount = 0 # Counts since start of run
runStartTime = datetime.datetime.now()
timeSinceRunStart = datetime.datetime.now() - runStartTime
minuteStartTime = runStartTime
timeSinceMinuteStart = minuteStartTime - runStartTime
done = 0 # Set to 1 if the data taking should end
nMinuteCount = 0  # Counts in the last minute
nMinutes = 0 # Number of minutes since start of run
prevEventTime = datetime.datetime.now()
liveTime = 0  # Total live time, not counting processing and STRETCH time.

# Loop while checking for a high signal on pin 37
try:
    while done < 1:
        if maxtime > 0 and timeSinceRunStart.total_seconds() > maxtime :
            done = 1
        if path.exists(stopfile):
            done = 1
        if GPIO.input(37)==1:  # Check for a STRETCH signal
            # Have an event, process it
            currentTime = datetime.datetime.now()
            timeSinceRunStart = currentTime - runStartTime
            timeSinceMinuteStart = currentTime - minuteStartTime
            timeSincePrevEvent = currentTime - prevEventTime
            liveTime = liveTime + timeSincePrevEvent.total_seconds()
            nCount = nCount + 1
            nMinuteCount = nMinuteCount + 1
            print(nCount,timeSinceRunStart.total_seconds(), timeSincePrevEvent.total_seconds(), liveTime, currentTime.year, currentTime.month, currentTime.day, currentTime.hour, currentTime.minute, currentTime.second, currentTime.microsecond, ADC1, ADC2, AUX1, AUX2, AUX3, file=eventsOut, end="\n")
            if timeSinceMinuteStart.total_seconds() > 60:
                # A minute has passed, calculate the rate per minute, write it out, and update run summary
                nMinutes = nMinutes + 1
                print(nMinutes,nMinuteCount, file=minutesOut, end="\n")
                minutesOut.flush()
                eventsOut.flush()
                if nMinutes > 4:
                    os.system("CosmicRunSummary") # Make updated summary plots for monitoring
                minuteStartTime = datetime.datetime.now() # Start a new one minute clock
                nMinuteCount = 0 # Reset the count for the next minute
            while GPIO.input(37)==1: # Wait for the Stretch signal to fall
                time.sleep(0.00001)        
            prevEventTime = datetime.datetime.now()

finally:
    # Calculate total rate
    endTime = datetime.datetime.now()
    timeSinceRunStart = endTime - runStartTime
    nSeconds = timeSinceRunStart.total_seconds()
    rate = int(1000*nCount/nSeconds) # count rate in mHz; choose mHz to simplify as an integer
    rateErr = int(1000*math.sqrt(nCount)/nSeconds)
    
    # Now write summary information to the screen and a file
    print("")
    print("Raw count rate = ",nCount,"/",nSeconds,"=",rate,"+-",rateErr,"mHz")
    fileSummary = open(summaryfile, "w") 
    print(nCount,int(1000*nSeconds),rate,rateErr,file=fileSummary)
    print("NCount=",nCount," RunTime=",int(1000*nSeconds)," seconds Rate=",rate," &plusmn; ",rateErr," mHz")

    # Close and clean
    eventsOut.close() 
    minutesOut.close() 
    print("Run ended")
    GPIO.cleanup()
    fileSummary.close()
    os.system("CosmicRunSummary") # Make final summary plots
    # Remove the stopfile if it exists
    if path.exists(stopfile):
        os.system("rm -f "+stopfile) 
