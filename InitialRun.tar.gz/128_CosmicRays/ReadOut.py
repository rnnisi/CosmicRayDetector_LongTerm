#!/usr/bin/env python3

import numpy  as  np
import math
import sys
import os
import os.path
from os import path
import RPi.GPIO as GPIO
import time
import datetime
import sys

GPIO.setmode(GPIO.BOARD)
GPIO.setup(37,GPIO.IN)
n= 0
while n < 10:
	if GPIO.input(37)==1:
		currentTime = datetime.datetime.now()
		print(currentTime)
		n = n +1
		while GPIO.input(37)==1:
			time.sleep(0.00001)
